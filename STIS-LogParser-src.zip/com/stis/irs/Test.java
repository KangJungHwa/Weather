package com.stis.irs;

public class Test {
   public static void main(String[] args) {
	String test="11,22,33,";
	System.out.println("result--"+test.substring(0,test.lastIndexOf(",")));
}
}
