#!/bin/bash -l
#HIVE_BIN="/opt/cloudera/parcels/CDH/lib/hive/bin/hive"
HIVE_BIN=hive
echo $1
hive -S -hiveconf TABLENAME=$1 -f table_select_limit_10.hql | tr "\t" "," > /hiveout/test_$1.csv